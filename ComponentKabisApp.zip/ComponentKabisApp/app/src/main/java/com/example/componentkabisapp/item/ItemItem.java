package com.example.componentkabisapp.item;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Paint;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;


import androidx.recyclerview.widget.RecyclerView;

import com.example.componentkabisapp.BaseApp;
import com.example.componentkabisapp.PicassoTrustAll;
import com.example.componentkabisapp.R;
import com.example.componentkabisapp.models.Pesanan;
import com.mikepenz.fastadapter.items.AbstractItem;

import java.util.List;
import java.util.Objects;

import butterknife.BindView;
import butterknife.ButterKnife;
import io.realm.Realm;

public class ItemItem extends AbstractItem<ItemItem, ItemItem.ViewHolder> {
    private final Context context;
    private final OnCalculatePrice calculatePrice;
    public int id;
    public String name;
    public long price;
    public long cost;

    public int jumlah;
    private Realm realm;

    public ItemItem(Context context, OnCalculatePrice calculatePrice) {
        this.context = context;
        this.calculatePrice = calculatePrice;

    }

    @Override
    public int getType() {
        return R.id.list_item;
    }

    @Override
    public void bindView(final ItemItem.ViewHolder holder, List payloads) {
        super.bindView(holder, payloads);
        realm = BaseApp.getInstance(context).getRealmInstance();
        holder.name.setText(name);
        holder.price.setText(String.valueOf(cost));


    }

    private void CalculateCost() {
            cost = 1 * price;

    }

    private void AddPesanan(int id, long totalHarga, int qty) {
        Pesanan pesananitem = new Pesanan();
        pesananitem.setIdItem(id);
        pesananitem.setTotalHarga(totalHarga);
        pesananitem.setQty(qty);
        realm.beginTransaction();
        realm.copyToRealm(pesananitem);
        realm.commitTransaction();

    }

    private void UpdatePesanan(int id, long totalHarga, int qty) {
        realm.beginTransaction();
        Pesanan updateItem = realm.where(Pesanan.class).equalTo("id", id).findFirst();
        Objects.requireNonNull(updateItem).setTotalHarga(totalHarga);
        updateItem.setQty(qty);
        realm.copyToRealm(updateItem);
        realm.commitTransaction();

    }

    private void DeletePesanan(int id) {
        realm.beginTransaction();
        Pesanan deleteItem= realm.where(Pesanan.class).equalTo("id", id).findFirst();
        Objects.requireNonNull(deleteItem).deleteFromRealm();
        realm.commitTransaction();
    }


    @Override
    public int getLayoutRes() {
        return R.layout.item_item;
    }

    public interface OnCalculatePrice {
        void calculatePrice();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.itemitem)
        TextView name;

        @BindView(R.id.price)
        TextView price;

        @BindView(R.id.pilih)
        CheckBox pilih;


        public ViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
