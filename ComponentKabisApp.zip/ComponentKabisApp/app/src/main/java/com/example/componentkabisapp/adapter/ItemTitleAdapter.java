package com.example.componentkabisapp.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.componentkabisapp.PicassoTrustAll;
import com.example.componentkabisapp.R;
import com.example.componentkabisapp.activity.DetailItemTitleActivity;
import com.example.componentkabisapp.models.ItemModel;
import com.example.componentkabisapp.models.ItemTitleModel;


import java.util.List;

public class ItemTitleAdapter extends RecyclerView.Adapter<ItemTitleAdapter.ViewHolder>{

    private List<ItemTitleModel> list;
    private Context context;

    public ItemTitleAdapter(Context context, List<ItemTitleModel> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_title, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        ItemTitleModel itemTitleModel = list.get(position);

        holder.name.setText(itemTitleModel.getName());

        PicassoTrustAll.getInstance(context)
                .load(itemTitleModel.getIcon_url())
                .resize(250, 250)
                .into(holder.icon);


            holder.list_item.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, DetailItemTitleActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.putExtra("id", itemTitleModel.getId());
                    intent.putExtra("judul", itemTitleModel.getName());
                    context.startActivity(intent);

                }
            });


    }

    @Override
    public int getItemCount() {
        return (list != null) ? list.size() : 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView name;
        private ImageView icon, help;
        private LinearLayout list_item;

        public ViewHolder(View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.itemtitle);
            icon = itemView.findViewById(R.id.icon);
            list_item = itemView.findViewById(R.id.list_itemtitle);

        }
    }
}
