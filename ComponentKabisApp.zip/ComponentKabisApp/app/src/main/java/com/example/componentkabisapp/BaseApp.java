package com.example.componentkabisapp;

import android.app.Application;
import android.content.Context;

import androidx.multidex.MultiDex;

import io.realm.Realm;
import io.realm.RealmConfiguration;

public class BaseApp extends Application {

    private static final int SCHEMA_VERSION = 0;


    private Realm realmInstance;

    public static BaseApp getInstance(Context context) {
        return (BaseApp) context.getApplicationContext();
    }

    @Override
    public void onCreate() {
        super.onCreate();

        Realm.init(this);
        RealmConfiguration config = new RealmConfiguration.Builder()
                .schemaVersion(SCHEMA_VERSION)
                .deleteRealmIfMigrationNeeded()
                .build();


//        realmInstance = Realm.getInstance(config);
        realmInstance = Realm.getDefaultInstance();
        realmInstance.beginTransaction();
        realmInstance.commitTransaction();


    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);
    }


    public final Realm getRealmInstance() {
        return realmInstance;
    }


}
