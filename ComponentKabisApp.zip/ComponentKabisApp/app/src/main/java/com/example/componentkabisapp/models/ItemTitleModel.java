package com.example.componentkabisapp.models;


import java.util.ArrayList;

public class ItemTitleModel {

    public Integer id;
    public String name;
    public String icon_url;

    public ItemTitleModel() {

    }


    public ItemTitleModel(Integer id, String name, String icon_url) {
        this.name = name;
        this.icon_url = icon_url;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIcon_url() {
        return icon_url;
    }

    public void setIcon_url(String icon_url) {
        this.icon_url = icon_url;
    }


}
