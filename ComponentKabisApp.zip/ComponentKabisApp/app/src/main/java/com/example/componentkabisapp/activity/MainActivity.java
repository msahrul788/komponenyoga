package com.example.componentkabisapp.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.componentkabisapp.R;
import com.example.componentkabisapp.adapter.ItemTitleAdapter;
import com.example.componentkabisapp.models.ItemModel;
import com.example.componentkabisapp.models.ItemTitleModel;
import com.google.gson.JsonArray;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView itemlist;
    private LinearLayout rlnodata;
//    private ItemTitleAdapter adapter;
    private LinearLayoutManager linearLayoutManager;
    private List<ItemTitleModel> itemTitleModels;
    private List<ItemModel> itemModels;

    private DividerItemDecoration dividerItemDecoration;
    private RecyclerView.Adapter adapter;
    private TextView nitem;

    private String url = "http://taqtis.id/input.json";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        itemTitleModels = new ArrayList<>();
        itemModels = new ArrayList<>();

        adapter = new ItemTitleAdapter(getApplicationContext() ,itemTitleModels);

        rlnodata = findViewById(R.id.rlnodata);
        itemlist = findViewById(R.id.itemlist);
        nitem = findViewById(R.id.nitem);

        linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        dividerItemDecoration = new DividerItemDecoration(itemlist.getContext(), linearLayoutManager.getOrientation());

        itemlist.setHasFixedSize(true);
        itemlist.setLayoutManager(linearLayoutManager);
        itemlist.addItemDecoration(dividerItemDecoration);
        itemlist.setAdapter(adapter);

        getData();
    }

    private void getData() {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.show();

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(url, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                if (response.length()==0) {
                    itemlist.setVisibility(View.GONE);
                    rlnodata.setVisibility(View.VISIBLE);
                }

                for (int i = 0; i < response.length(); i++) {
                    try {
                        nitem.setText("Content Subtitle ("+ response.length() +" items)");

                        JSONObject jsonObject = response.getJSONObject(i);
                        itemlist.setVisibility(View.VISIBLE);
                        rlnodata.setVisibility(View.GONE);

                        ItemTitleModel itemTitleModel = new ItemTitleModel();
                        itemTitleModel.setName(jsonObject.getString("name"));
                        itemTitleModel.setIcon_url(jsonObject.getString("icon_url"));

                        itemTitleModels.add(itemTitleModel);

                    } catch (JSONException e) {
                        e.printStackTrace();
                        progressDialog.dismiss();
                    }
                }
                adapter.notifyDataSetChanged();
                progressDialog.dismiss();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("Volley", error.toString());
                progressDialog.dismiss();
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);
    }

//    public String loadJSONFromAsset() {
//        StringBuilder stringBuilder = new StringBuilder();
//        try {
//            InputStream is = getAssets().open("input.json");
//            BufferedReader bufferedReader = new BufferedReader(
//                    new InputStreamReader(is));
//
//            String line;
//            while ((line = bufferedReader.readLine()) != null) {
//                stringBuilder.append(line);
//            }
//
//            bufferedReader.close();
//
//            Log.d("X","Response Ready:"+stringBuilder.toString());
//
//            return stringBuilder.toString();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//
//        return null;
//
//    }
}