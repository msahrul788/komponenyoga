package com.example.componentkabisapp.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.componentkabisapp.PicassoTrustAll;
import com.example.componentkabisapp.R;
import com.example.componentkabisapp.activity.DetailItemTitleActivity;
import com.example.componentkabisapp.activity.ItemInformationActivity;
import com.example.componentkabisapp.models.ItemModel;

import java.util.ArrayList;
import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ViewHolder>{

    private List<ItemModel> list;
    private Context context;

    public ItemAdapter(Context context, List<ItemModel> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_item, parent, false);
        return new ViewHolder(v);
    }


    @Override
    public void onBindViewHolder(ItemAdapter.ViewHolder holder, int position) {
        ItemModel itemModel = list.get(position);
        holder.name.setText(itemModel.getName());

        PicassoTrustAll.getInstance(context)
                .load(itemModel.getIcon_url())
                .resize(250, 250)
                .into(holder.icon);

        if(itemModel.getCurrency().equals("IDR")){
            holder.price.setText("Rp. " + itemModel.getPrice());
        }else if(itemModel.getCurrency().equals("USD")){
            holder.price.setText("$ " + itemModel.getPrice());
        }else{
            holder.price.setText("$ " + itemModel.getPrice());
        }

        if(itemModel.getHelp().equals("true")) {
            holder.help.setVisibility(View.VISIBLE);
            holder.help.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, ItemInformationActivity.class);
                    context.startActivity(intent);
                    ((Activity) context).finish();
                }
            });
        }else{
            holder.help.setVisibility(View.GONE);
        }


    }

    @Override
    public int getItemCount() {
        return (list != null) ? list.size() : 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView name, currency, price;
        private ImageView icon,help;

        public ViewHolder(View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.itemitem);
            price = itemView.findViewById(R.id.price);
            help = itemView.findViewById(R.id.help);
            icon = itemView.findViewById(R.id.icon);

        }
    }
}
