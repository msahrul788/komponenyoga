package com.example.componentkabisapp.item;

import androidx.recyclerview.widget.RecyclerView;

public class ItemItem {

}
