package com.example.componentkabisapp.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

public class ItemModel {

    public Integer id;
    public String name;
    public String icon_url;
    public String currency;
    public String price;
    public String help;
    public String help_info;
    public String other_currency;

    public ItemModel() {

    }


    public ItemModel(Integer id, String name, String icon_url, String currency, String price, String help, String help_info, String other_currency) {
        this.id = id;
        this.name = name;
        this.icon_url = icon_url;
        this.currency = currency;
        this.price = price;
        this.help= help;
        this.help_info = help_info;
        this.other_currency = other_currency;
    }
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getHelp() {
        return help;
    }

    public void setHelp(String help) {
        this.help = help;
    }

    public String getIcon_url() {
        return icon_url;
    }

    public void setIcon_url(String icon_url) {
        this.icon_url = icon_url;
    }

    public String getHelp_info() {
        return help_info;
    }

    public void setHelp_info(String help_info) {
        this.help_info = help_info;
    }


    public String getOther_currency() {
        return other_currency;
    }

    public void setOther_currency(String other_currency) {
        this.other_currency = other_currency;
    }
}
