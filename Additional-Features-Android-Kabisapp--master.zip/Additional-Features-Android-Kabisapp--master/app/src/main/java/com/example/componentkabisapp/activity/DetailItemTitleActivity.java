package com.example.componentkabisapp.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.componentkabisapp.R;
import com.example.componentkabisapp.adapter.ItemAdapter;
import com.example.componentkabisapp.models.ItemModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;


public class DetailItemTitleActivity extends AppCompatActivity {

    private ImageView back_btn;
    private TextView judul;
    private RecyclerView itemlist;
    private LinearLayout rlnodata;

    private List<ItemModel> item;

    private LinearLayoutManager linearLayoutManager;

    private DividerItemDecoration dividerItemDecoration;
    private RecyclerView.Adapter adapter;

    private String url = "http://taqtis.id/input.json";

    String id,name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_item_title);

        item = new ArrayList<>();

        judul = findViewById(R.id.judulitem);
        back_btn = findViewById(R.id.back_btn);
        rlnodata = findViewById(R.id.rlnodata);
        itemlist = findViewById(R.id.itemlist);

        adapter = new ItemAdapter(getApplicationContext() , item);

        linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        dividerItemDecoration = new DividerItemDecoration(itemlist.getContext(), linearLayoutManager.getOrientation());

        itemlist.setHasFixedSize(true);
        itemlist.setLayoutManager(linearLayoutManager);
        itemlist.addItemDecoration(dividerItemDecoration);
        itemlist.setAdapter(adapter);

        Intent i = getIntent();
        name = i.getStringExtra("name");
        judul.setText(i.getStringExtra("judul"));


        back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        getData();
    }

    private void getData() {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.show();

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(url, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                if (response.length()==0) {
                    itemlist.setVisibility(View.GONE);
                    rlnodata.setVisibility(View.VISIBLE);
                }
                for (int i = 0; i < response.length(); i++) {
                    try {
                        JSONObject jsonObject = response.getJSONObject(i);
                        itemlist.setVisibility(View.VISIBLE);
                        rlnodata.setVisibility(View.GONE);

//                        if(jsonObject.getString("name").equals(name) ) {
                            JSONArray jsonArray = jsonObject.getJSONArray("item");

                            for (int j = 0; j < jsonArray.length(); j++) {
                                JSONObject itemDetail = jsonArray.getJSONObject(j);
                                ItemModel itemModel = new ItemModel();
                                itemModel.setName(itemDetail.getString("name"));
                                itemModel.setCurrency(itemDetail.getString("currency"));
                                itemModel.setPrice(itemDetail.getString("price"));
                                itemModel.setIcon_url(itemDetail.getString("icon_url"));
                                itemModel.setHelp(itemDetail.getString("help"));
                                item.add(itemModel);
                            }
//                        }else{
//                            itemlist.setVisibility(View.GONE);
//                            rlnodata.setVisibility(View.VISIBLE);
//                        }


                    } catch (JSONException e) {
                        e.printStackTrace();
                        progressDialog.dismiss();
                    }
                }
                adapter.notifyDataSetChanged();
                progressDialog.dismiss();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("Volley", error.toString());
                progressDialog.dismiss();
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);
    }

    public String loadJSONFromAsset() {
        String json = null;
        try
        {
            InputStream stream = getAssets().open( "input.json" );
            int size = stream.available();

            byte[] bytes = new byte[size];
            stream.read(bytes);
            stream.close();

            return new String( bytes );

        } catch ( IOException e ) {
            Log.i("GuiFormData", "IOException: " + e.getMessage() );
        }
        return json;
    }

//    @Override
//    public void onBackPressed() {
//        List<Pesanan> existingItem = realm.where(Pesanan.class).findAll();
//
//        int quantity = 0;
//        for (int p = 0; p < existingItem.size(); p++) {
//            quantity += Objects.requireNonNull(existingItem.get(p)).getQty();
//        }
//
//        if (quantity > 0) {
//            new AlertDialog.Builder(this, R.style.DialogStyle)
//                    .setTitle("Delete current order(s)?")
//                    .setMessage("Leaving this page will cause you lose all the order you've made. Continue?")
//                    .setPositiveButton("YES!", new DialogInterface.OnClickListener() {
//                        @Override
//                        public void onClick(DialogInterface dialog, int which) {
//                            DeletePesanan();
//                            finish();
//                        }
//                    })
//                    .setNegativeButton("NO", null)
//                    .show();
//        } else {
//            finish();
//        }
//    }
//
//    private void DeletePesanan() {
//        RealmResults<Pesanan> deleteFood = realm.where(Pesanan.class).findAll();
//        realm.beginTransaction();
//        deleteFood.deleteAllFromRealm();
//        realm.commitTransaction();
//    }

}